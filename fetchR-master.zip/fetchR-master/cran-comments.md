## Test environments
* local ubuntu install 18.04.4, R 3.6.2
* ubuntu 14.04.5 LTS (on travis-ci; devel and release)
* win-builder (devel and release)

## R CMD check results
There were no ERRORs, WARNINGs or NOTEs.

## Downstream dependencies
There are currently no downstream dependencies.
